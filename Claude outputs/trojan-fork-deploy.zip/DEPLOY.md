# Deploy in about 10 minutes (Render, free)

1. Create a new empty public GitHub repo under your own account (for example `trojan-fork`).
2. Put this folder's contents in it. Either drag the files into GitHub's "uploading an existing file" page, or from this folder run:

   ```bash
   git init && git add . && git commit -m "Trojan Fork"
   git branch -M main
   git remote add origin https://github.com/<you>/trojan-fork.git
   git push -u origin main
   ```

3. On render.com choose New, then Blueprint, pick the repo, and approve. Render reads `render.yaml`.
4. Optional: in the service's Environment tab set `OPENAI_API_KEY`. The app works without it.
5. When the deploy is green, open `https://<service>.onrender.com/ui/`. Put that address in Devpost and in `README.md`.

Free services sleep after about 15 minutes idle and take up to a minute to wake. Open the link a few minutes before judging, or point a free uptime monitor (for example UptimeRobot) at `/health` every 5 minutes.

Accounts live in a SQLite file that resets whenever a free service restarts. Guest mode and the profile saved in the browser are not affected.
