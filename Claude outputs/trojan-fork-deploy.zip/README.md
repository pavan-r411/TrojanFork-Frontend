# Trojan Fork

**Your goals. Your campus. Your plate.**

Trojan Fork is a mobile-first web app that plans a USC student's day of eating. A student sets a goal, diet, allergies and budget once, then gets three real options for each meal, either from today's USC dining hall menus or from restaurants within walking distance of campus. Each pick updates what is left for the rest of the day.

Built for the AI@USC Hackathon 2026, theme "By Trojans, For Trojans".

Live demo: _add the Render URL here, ending in `/ui/`_

## What it does

- **USC Dining.** Reads today's menus for Village, Everybody's Kitchen and Parkside straight from the USC Hospitality feed, composes plates the way a student actually builds one, and treats a dining hall visit as one meal swipe (never a per-dish price).
- **Off campus.** Ranks real menu items from 72 restaurants near campus by distance, price, cuisine and fit, with a hard cash limit per meal. Walking distance is three bands (up to 0.3 mi, 0.3 to 0.5 mi, 0.5 to 1.5 mi), all on by default, so every open restaurant is reachable and none is dropped for distance. Turn a band off to stay closer.
- **Sorting that really reorders.** Best fit, Closest, Cheapest and Protein (Lighter in USC mode) each sort the whole eligible pool, not just the top few. "Next 3" pages through it and "See all matches" lists every option.
- **Full day.** Breakfast, lunch and dinner appear together with three options each. Choosing one locks it and re-plans the other two around it.
- **Dish photos.** 231 off-campus dishes show a photo of that exact dish (see "Dish photos" below). Cards without one keep an icon.
- **One profile, both modes.** Goal, body, diet, allergies and dislikes feed a Mifflin-St Jeor calorie and protein target, split across breakfast, lunch and dinner.
- **A plan that adapts.** Picking a meal recalculates the next meal's target and the budget left. "My day" shows totals and can be shared.
- **Plain-English requests.** "Vegetarian high protein lunch under $14" is parsed into filters. Free text can only add restrictions, never remove one.
- **Student Basic Needs.** If swipes or budget run out, the app points to USC's food pantry and emergency swipe program.

## Why you can trust the output

Code decides what is safe. AI only helps with wording.

1. **Hard filters run first and fail closed:** allergies (with synonyms and ingredient keywords), strict diets including halal and pescatarian, dislikes, cash cap, walking distance, opening hours and item availability windows. A dish whose allergen status is unknown is hidden from an allergic student rather than shown as safe.
2. **Transparent ranking second:** a weighted score for calorie fit, protein fit, price, distance, cuisine and how confident the nutrition data is, with a small penalty for repeating a venue. Cuisine is a soft preference, so it never overrides a safety rule.
3. **Honest about data:** USC publishes no nutrition, so calories on dining hall dishes are estimates and are marked with "≈". Off-campus items come from a saved snapshot. Walking times are straight-line estimates. Photos are shown only where they match the dish, and the Details sheet says where each one came from.
4. **Audited:** an independent checker, written separately from the engine, re-verifies every option returned for 2,000 random student profiles, across every distance band and sort. Result: 0 violations.

Not medical advice. Always confirm allergens with the restaurant or dining hall staff.

## Architecture

- `TrojanFork-Backend`: FastAPI. `flow/engine.py` (filters, scoring, plan logic), `flow/roles.py` (plate composition for dining halls), `flow/feed.py` (USC feed with live, cached and saved fallbacks), `flow/parse.py` (free-text requests, rules first with an optional OpenAI pass), `flow/verify.py` (independent safety checker). It also serves the frontend at `/ui/`.
- `TrojanFork-Frontend`: static ES modules, no build step. Burgundy, ivory and gold.
- Data: `restaurants_usc_complete.json` (restaurants and dining venues) and the daily USC feed snapshots in `data/`.

The OpenAI key is optional. Without it the app uses rule-based parsing and template explanations, and the filters behave identically.

## Run it locally

```bash
cd TrojanFork-Backend
python -m venv .venv && source .venv/bin/activate
pip install -e .
cp .env.example .env        # optional: add OPENAI_API_KEY
uvicorn trojanbites_extract.api.app:app --port 8000
```

Open http://127.0.0.1:8000/ui/. The frontend must stay next to the backend folder, because the backend serves it.

## Checks

```bash
cd TrojanFork-Backend
pytest tests                                 # 150 pass; 8 legacy /v1/plan tests are marked expected-fail
pytest tests/test_flow.py                    # 39 engine, parser, sort, distance-band, photo and feed tests
python scripts/flow_accuracy.py --n 2000     # random-profile safety audit, exits non-zero on any violation
cd ../TrojanFork-Frontend && node scripts/targets-test.mjs && node scripts/live-plan-test.mjs   # calorie math and day-plan state
```

## Dish photos

Photos come from `TrojanFork-Backend/dish_images.json`, which maps a dish id to a file in `TrojanFork-Frontend/assets/dishes/`. We built it from a scraped bundle of restaurant imagery and kept only photos that are

- of the same dish (an exact match, or the same dish at another branch of the same chain),
- from the chain's own site, the restaurant's own site or its delivery-app menu, and
- at least 200 px on the short side and not a cutout with a black background.

Yelp and Google Maps customer photos and blog images were left out on purpose. The Details sheet names the source of each photo and notes that a portion may look different. These are third-party images shown to identify the dish in a non-commercial hackathon demo; remove `dish_images.json` and the app runs without any photo. `python scripts/build_dish_images.py` rebuilds the mapping from the bundle.

## Limits we are upfront about

- Off-campus menus and prices are a snapshot and can drift. One restaurant (Tacoyo's) is reported closed and is listed as unavailable rather than recommended.
- About 4 in 10 off-campus dishes have a photo; the rest show an icon.
- Dining hall calories are estimated from dish names; allergen tags come from USC's own labels where present.
- Accounts are stored in a local SQLite file, so they reset when a free host restarts. Guest mode and the profile saved in the browser are unaffected.

## Team

Built by Gurpreet Kukkar, Pavan Kumar Ramesh and Murali Krishna for AI@USC Hackathon 2026.
